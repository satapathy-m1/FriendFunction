/*
Write a program to maintain the records of person with details (name and age) and
find the eldest among them. The program must use this pointer to return the result.
*/


#include <iostream>
#include <string>
using namespace std;

class Person {
private:
    string name;
    int age;

public:
    
    Person(string personName="", int personAge=0) {
        name = personName;
        age = personAge;
    }
    
    void inputDetails() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter age: ";
        cin >> age;
    }

    
    void display(){
        cout << "Name: " << name << ", Age: " << age << endl;
    }

    
    int getAge(){
        return age;
    }

    
    string getName(){
        return name;
    }
};


Person* findEldest(Person* persons, int count) {
    Person* eldest = &persons[0]; 
    for (int i = 1; i < count; i++) {
        if (persons[i].getAge() > eldest->getAge()) {
            eldest = &persons[i]; 
        }
    }
    return eldest;
}

int main() {
    int count;

    cout << "Enter the number of persons: ";
    cin >> count;

    
    Person* persons = new Person[count];

    
    for (int i = 0; i < count; i++) {
        cout << "Person " << (i + 1) << ":" << endl;
        persons[i].inputDetails();
    }

    // Find the eldest person
    Person* eldest = findEldest(persons, count);

    // Display the details of the eldest person
    cout << "The eldest person is:" << endl;
    eldest->display();

    // Clean up
    delete[] persons;

    return 0;
}


/*
output:-

Enter the number of persons: 3
Person 1:
Enter name: Alice
Enter age: 30
Person 2:
Enter name: Bob
Enter age: 45
Person 3:
Enter name: Charlie
Enter age: 25


The eldest person is:
Name: Bob, Age: 45

*/
