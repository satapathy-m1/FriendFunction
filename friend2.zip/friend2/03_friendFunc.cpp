/*
Define a class string and overload == to compare two strings and + operator for
concatenation of two strings
*/
#include <iostream>
#include <cstring>
using namespace std;

class String {
    char str[100];
public:
    String(const char* s) {
        strcpy(str, s);
        //str[sizeof(str) - 1] = '\0'; 
    }

    bool operator==(const String& obj){
        return strcmp(str, obj.str) == 0;
    }

    String operator+(const String& obj){
        char concatenated[200]; 
        strcpy(concatenated, str);
        strcat(concatenated, obj.str);
        return String(concatenated);
    }

    void display(){
        cout << str << endl;
    }
};

int main() {
    String s1("Hello, ");
    String s2("Hello, ");

    String s3 = s1 + s2;

    cout << "String 1: ";
    s1.display();
    
    cout << "String 2: ";
    s2.display();
    
    cout << "Concatenated String: ";
    s3.display();

    if (s1 == s2) {
        cout << "Strings are equal." << endl;
    } else {
        cout << "Strings are not equal." << endl;
    }

    return 0;
}

/*
output
String 1: Hello, 
String 2: Hello, 
Concatenated String: Hello, Hello, 
Strings are equal.

*/
