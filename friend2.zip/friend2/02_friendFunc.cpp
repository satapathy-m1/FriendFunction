#include <iostream>
using namespace std;

class Complex {
    float real;
    float imag;
public:
    Complex(float r = 0, float i = 0) {  
        real = r;
        imag = i;
    }
    
    void display() const {
        cout << real << " + " << imag << "i" << endl;
    }
    
    friend void add(const Complex&, const Complex&);
};

void add(const Complex& c1, const Complex& c2) {
    cout << c1.real + c2.real << " + " << c1.imag + c2.imag << "i" << endl;
}

int main() {
    float r1, i1, r2, i2;
    
    cout << "Enter first complex number (real and imaginary parts): ";
    cin >> r1 >> i1;
    Complex c1(r1, i1);
    
    cout << "Enter second complex number (real and imaginary parts): ";
    cin >> r2 >> i2;
    Complex c2(r2, i2);
    
    cout << "First complex number: ";
    c1.display();
    
    cout << "Second complex number: ";
    c2.display();
    
    cout << "Sum: ";
    add(c1, c2);
    
    return 0;
}

/*
output

Enter first complex number (real and imaginary parts): 3 4
Enter second complex number (real and imaginary parts): 1 2


First complex number: 3 + 4i
Second complex number: 1 + 2i
Sum: 4 + 6i

*/

