#include <iostream>
#include <string>
using namespace std;

class FriendHelper;

class Student {
private:
    string name;
    int marks1, marks2, marks3;

public:
    void get_data() {
        cout << "Enter Student Name: ";
        cin >> name;
        cout << "Enter marks in subject 1: ";
        cin >> marks1;
        cout << "Enter marks in subject 2: ";
        cin >> marks2;
        cout << "Enter marks in subject 3: ";
        cin >> marks3;
    }

    void display(FriendHelper& obj);
};

class FriendHelper {
public:
    float mark_avg(Student& s) {
        float average = (s.marks1 + s.marks2 + s.marks3) / 3.0;
        return average;
    }
};

void Student::display(FriendHelper& obj) {
    float avg = obj.mark_avg(*this);
    cout << "Student Name: " << name << endl;
    cout << "Average Marks: " << avg << endl;
}

int main() {
    Student student1;
    FriendHelper obj;

    student1.get_data();
    student1.display(obj);

    return 0;
}


/*
 output:-
 Enter Student Name: prabir
Enter marks in subject 1: 85
Enter marks in subject 2: 90
Enter marks in subject 3: 80


Student Name: prabir
Average Marks: 85


*/
