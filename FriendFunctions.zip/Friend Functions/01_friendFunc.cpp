//Write a program to swap the values two integer members of different classes

//using friend function.
#include <iostream>
using namespace std;

class ClassB; // Forward declaration

class ClassA {
    int a;
public:
    /*ClassA(int val) {
        a = val;
    }*/
    ClassA(){
    	 cout << "Give the ele for A ";
        cin >> a;
	this -> a = a;
    }
    void display() {
        cout << "ClassA: " << a << endl;
    }
    friend void swap(ClassA&, ClassB&);
};

class ClassB {
    int b;
public:
    ClassB() {
        cout <<"Give the value of B ";
        cin >> b;
	this -> b = b;
    }
    void display() {
        cout << "ClassB: " << b << endl;
    }
    friend void swap(ClassA&, ClassB&);
};

void swap(ClassA& objA, ClassB& objB) {
    
    int temp = objA.a;
    objA.a = objB.b;
    objB.b = temp;
}

int main() {
    ClassA objA;
    ClassB objB;
    
    objA.display();
    objB.display();

    swap(objA, objB);

    objA.display();
    objB.display();

    return 0;
}

