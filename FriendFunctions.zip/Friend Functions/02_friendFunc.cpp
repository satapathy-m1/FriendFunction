/*Write a program for addition of two complex numbers using friend function (use
constructor function to initialize data members of complex class).*/

#include <iostream>
using namespace std;

class Complex {
    float real;
    float imag;
public:
    Complex() {
    	cin >> real;
    	cin >> imag;
    	this -> real = real;
    	this -> imag = imag;
    	cout << endl << endl;
        
    }
    void display() {
        cout << real << " + " << imag << "i" << endl;
    }
    friend void add(const Complex&, const Complex&);
};

void add(const Complex& c1, const Complex& c2) {
    cout << c1.real + c2.real << " + "<< c1.imag + c2.imag <<"i" << endl << endl;
}

int main() {
    Complex c1;
    Complex c2;
    
    
    
    cout << "First complex number: ";
    c1.display();
    
    cout << "Second complex number: ";
    c2.display();
    
    cout << "Sum: ";
    add(c1, c2);

    return 0;
}

