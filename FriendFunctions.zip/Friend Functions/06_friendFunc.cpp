/*
Write a C++ program to count the number of persons inside a bank, by increasing count
whenever a person enters a bank, using an increment(++) operator overloading function, and
decrease the count whenever a person leaves the bank using a decrement(--) operator
overloading function inside a class
*/

#include <iostream>

using namespace std;

class Bank {
private:
    int count;

public:
   
    Bank(){
    	count = 0;
    }

    
    Bank& operator++() {
        ++count; 
        return *this; 
    }


    Bank& operator--() {
        if (count > 0) {
            --count; 
        } else {
            cout << "No persons in the bank to remove." << endl;
        }
        return *this;
    }

    void displayCount() const {
        cout << "Number of persons in the bank: " << count << endl;
    }
};

int main() {
    Bank bank; 
  
    cout << "A person enters the bank." << endl;
    ++bank; 
    bank.displayCount();
    cout << "A person enters the bank." << endl;
    ++bank; 
    bank.displayCount();
    cout << "A person leaves the bank." << endl;
    --bank; 
    bank.displayCount();
    cout << "A person leaves the bank." << endl;
    --bank;
    bank.displayCount();
    cout << "A person leaves the bank." << endl;
    --bank;
    bank.displayCount();

    return 0;
}

