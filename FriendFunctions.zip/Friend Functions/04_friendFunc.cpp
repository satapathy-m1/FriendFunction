/*
	Write a program to perform matrix addition using operator overloading concept.
	Matrix
	a[100][100], m,n
	void getdata()
	void show()
	matrix operator+(matrix &x,matrix &y)
*/
#include <iostream>
using namespace std;

class Matrix {
private:
    int a[100][100];
    int m, n;

public:
    Matrix(int rows, int cols) {
        m = rows;
        n = cols;
    }

    
    void getData() {
        cout << "Enter elements of the matrix (" << m << "x" << n << "):" << endl;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                cin >> a[i][j];
            }
        }
    }

   
    void show(){
        cout << "Matrix (" << m << "x" << n << "):" << endl;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                cout << a[i][j] << " ";
            }
            cout << endl;
        }
    }

    
    Matrix operator+(const Matrix &y) {
    
        Matrix result(m, n);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                result.a[i][j] = a[i][j] + y.a[i][j];
            }
        }
        return result;
    }
};

int main() {
    int rows, cols;

    
    cout << "Enter number of rows and columns for matrices: ";
    cin >> rows >> cols;

    
    Matrix x(rows, cols);
    Matrix y(rows, cols);
    
    x.getData();
    y.getData();
    
    Matrix result = x + y;

    result.show();

    return 0;
}

